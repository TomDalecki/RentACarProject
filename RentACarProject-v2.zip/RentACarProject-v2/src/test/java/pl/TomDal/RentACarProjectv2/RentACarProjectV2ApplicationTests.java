package pl.TomDal.RentACarProjectv2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RentACarProjectV2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
